/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arquitecturas;

import arquitecturas.analisis.AnalisisFactory;
import arquitecturas.analisis.AnalisisMotivos;
import arquitecturas.analisis.AnalisisSecuencia;
import arquitecturas.creacionales.singleton.ConexionBD;
import arquitecturas.modelo.Fachada;
import arquitecturas.modelo.SecuenciaGenetica;
import arquitecturas.proxy.BDwriteProxy;
import arquitecturas.reporte.builder.GeneradorReporteBuilder;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author carol
 */
public class ARQUITECTURAS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // crea una sola instancia de un objeto 
       
        
        System.out.println("\n--- Lectura del archivo FASTA (Facade/Builder) ---");
           
            List<SecuenciaGenetica> secuencias;
            String rutaArchivo = "C:\\Users\\carol\\OneDrive\\Documentos\\U_CALDAS\\Maestria\\ArquitecturaSoftware\\BRCA1_datasets\\n" + //
                            "cbi_dataset\\data\\gene.fna"; 
          
            Fachada datos = new Fachada();

            secuencias =datos.leerFasta(rutaArchivo);
            System.out.println("cantidad de secuencias "+(secuencias.size()-1));

            System.out.println("\n--- Guardado en DB (Proxy/Singleton) ---");
            boolean isUserAuthorized= true;
           
            
           // GeneradorReporteBuilder reporte= new GeneradorReporteBuilder(archivo);
            
            BDwriteProxy writer = new BDwriteProxy(isUserAuthorized); 
            writer.guardarSecuencias(secuencias); 
            
            datos.analisis(secuencias);
          
       
    }
    
   
    
}
