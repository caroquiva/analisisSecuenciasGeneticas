/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arquitecturas.modelo;

import arquitecturas.analisis.AnalisisFactory;
import arquitecturas.analisis.AnalisisMotivos;
import arquitecturas.analisis.AnalisisSecuencia;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author carol
 */
public class Fachada {
    
 public Fachada() {
    }

public  List<SecuenciaGenetica> leerFasta(String rutaArchivo)  {
    List<SecuenciaGenetica> secuencias = new ArrayList<>();
   
        String idSecuenciaActual = null;
        StringBuilder secuenciaActual = new StringBuilder();
       

        try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
          
            while ((linea = br.readLine()) != null) {
                if (linea.startsWith(">")) {
                  
                    if (idSecuenciaActual != null) {
                     secuencias.add(new SecuenciaGenetica.Builder().id(idSecuenciaActual)
                   .secuencia(secuenciaActual).build());
                       secuenciaActual = new StringBuilder();
                    }
                   
                    idSecuenciaActual = linea.substring(1);
                    
                } else {
                    secuenciaActual.append(linea.trim());
                }
            }
            
            if (idSecuenciaActual != null) {
                secuencias.add(new SecuenciaGenetica.Builder().build());
                    }

        } catch (IOException e) {
            e.printStackTrace();
        }
return secuencias;

}

public  void analisis(List<SecuenciaGenetica> secuencias){
       String op="";
             System.out.println("\n--- Análisis de Secuencias (Factory/Strategy) ---");
         do{
            op= JOptionPane.showInputDialog("TIPO DE ANALISIS\n"+
                                                   "Digite el nuamero\n"+
                                                   "1. Alineamiento\n"+ 
                                                   "2. Deteccion de motivos\n"+
                                                   "3. Prediccion de Estructura\n"+
                                                    "4. Salir");  
            
        AnalisisSecuencia analisisSec = AnalisisFactory.crearAnalisis(op);
        switch (op) {
            case "1" : //*******ALINEAMIENTO********/
                analisisAlineamientos(secuencias,analisisSec);
                break;
            case "2" : //*******DETECCION DE MOTIVOS *********/
                analisisMotivos(secuencias);
                break;
            case "3" ://*******PREDICCION DE ESTRUCTURA *********/
                analisisPrediccion(secuencias,analisisSec);
                break;
            default : throw new AssertionError();
        }
         }while(!op.equals("4"));
}
 
   public static void analisisAlineamientos(List<SecuenciaGenetica> secuencias,AnalisisSecuencia analisisSec){
    if(secuencias.size()>1){
                JOptionPane.showMessageDialog(null, "Hay "+(secuencias.size()-1)+" Elige dos:");
                int primeraSec = Integer.parseInt(JOptionPane.showInputDialog("Primera Secuencia"));
                int segundaSec = Integer.parseInt(JOptionPane.showInputDialog("Segunda Secuencia"));
                                    
                analisisSec.analizar(secuencias.get(primeraSec-1),secuencias.get(segundaSec-1));
           
            }
            else{
                JOptionPane.showMessageDialog(null, "Debe subir un archivo con más de una secuencia");   
                }
   }

   public static void analisisMotivos(List<SecuenciaGenetica> secuencias){
       AnalisisMotivos motivos = AnalisisFactory.crearListaMotivos();
       List<Integer> resultadoD ;
       if(secuencias.size()>1){ 
                    
                    int secE= Integer.parseInt(JOptionPane.showInputDialog("Hay "+(secuencias.size()-1)+" Elige 1:"));
                    resultadoD = motivos.analizar(secuencias.get(secE-1));
                    System.out.println("POSICIONES EN LA QUE SE ENCUENTRA EL MOTIVO");
                    JOptionPane.showMessageDialog(null,"Total de motivos encontrados = "+resultadoD.size());
                    for (Integer parte : resultadoD) {
                         System.out.println(parte);            
                    }
                }
     else{
                    resultadoD = motivos.analizar(secuencias.get(0));
                   System.out.println("POSICIONES EN LA QUE SE ENCUENTRA EL MOTIVO");
                    JOptionPane.showMessageDialog(null,"Total de motivos encontrados = "+resultadoD.size());
                    for (Integer parte : resultadoD) {
                         System.out.println(parte);            
                    }
                }           
   }

   public static void analisisPrediccion(List<SecuenciaGenetica> secuencias,AnalisisSecuencia analisisSec){
    if(secuencias.size()>1){
                    int secE= Integer.parseInt(JOptionPane.showInputDialog("Hay "+(secuencias.size()-1)+" Elige 1:"));
                    analisisSec.analizar(secuencias.get(secE-1),null);
                 
                
                }

                else{
                    analisisSec.analizar(secuencias.get(0),null);
                  
                }
   }
}
