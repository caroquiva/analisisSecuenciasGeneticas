/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arquitecturas.modelo;

/**
 *
 * @author carol
 */
public class SecuenciaGenetica {
    
    public String id;
    public StringBuilder secuencia;
    

    public static class Builder {
        private String id = "";
        private StringBuilder secuencia ;
        
        
        public Builder(){
            this.secuencia = new StringBuilder();
        }

        public Builder id(String id) { this.id = id; return this; }
        public Builder secuencia(StringBuilder secuencia) { this.secuencia = secuencia; return this; }

        public SecuenciaGenetica build() {
            return new SecuenciaGenetica(id, secuencia);
        }
    }
    private SecuenciaGenetica(String id, StringBuilder secuencia) {
        this.id = id;        
        this.secuencia = secuencia;
    }
    
    public String getId() { return id; }
    public StringBuilder getSecuencia() { return secuencia; }

}
