/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arquitecturas.creacionales.singleton;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author carol
 */
public class ConexionBD {
     private ConexionBD(){}

    private static ConexionBD instance;
    private static Connection conexion;

    private static final String URL = "jdbc:mysql://localhost/secuenciagenetica";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "1234";

   
   
    public  Connection conectar() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            conexion = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            
            System.out.println("Conexión a BD establecida");
            return conexion;
        } catch (ClassNotFoundException e) {
            System.err.println("Error: No se encontró el driver de MySQL.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Error de conexión a la base de datos: " + e.getMessage());
            e.printStackTrace();
        }
        return conexion;
    }

    // Método para obtener la única instancia
    public static  ConexionBD getInstancia() {
        if (instance == null) {
            instance = new ConexionBD();
        }
        return instance;
    }

    // obtener la conexión activa
    public Connection getConnection() {
        return this.conexion;
    }

    //  cerrar la conexión
    public void closeConnection() throws SQLException {
        if (conexion != null) {
            try {
                conexion.close();
                System.out.println("Conexión a BD cerrada.");
            } catch (SQLException e) {
                System.err.println("Error al cerrar la conexión: " + e.getMessage());
            }
            finally{
                conexion.close();
            }
        }
    }
}