/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arquitecturas.proxy;

import arquitecturas.creacionales.singleton.ConexionBD;
import arquitecturas.modelo.Fachada;
import arquitecturas.modelo.SecuenciaGenetica;
import arquitecturas.reporte.builder.GeneradorReporteBuilder;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


/**
 *
 * @author carol
 */
public class GuardarSecuencia implements BDwrite{
            ConexionBD conectar = ConexionBD.getInstancia(); 
            GeneradorReporteBuilder reporte = new GeneradorReporteBuilder();
    public GuardarSecuencia() {
    }
            
            
@Override
    public boolean guardarSecuencias(List<SecuenciaGenetica> secuencias){
    
    
     try  {
           Connection conexion = conectar.conectar();
        
        String sql = "INSERT INTO secuencia (id_secuencia,secuencia) VALUES (?, ?)";
        
       
            PreparedStatement statement = conexion.prepareStatement(sql);
            for(int i=0;i<secuencias.size();i++){
                statement.setString(1, secuencias.get(i).getId());
                statement.setString(2, secuencias.get(i).getSecuencia().toString());
            
                int filasAfectadas = statement.executeUpdate();
            
                if (filasAfectadas > 0) {
                    System.out.println("Secuencia '" + secuencias.get(i).getId()+ "' guardada exitosamente en BD.");
                } else {
                    System.out.println("Error al guardar la secuencia.");
                }
                }
            conexion.close();

        } catch (SQLException e) {
            System.err.println("Error de SQL al guardar la secuencia: " + e.getMessage());
            e.printStackTrace();
        }
       
    return true;
}
  
    public boolean verificarSecuencias(List<SecuenciaGenetica> secuencias){
        boolean encontro=false;
      
        try{
            Connection conexion = conectar.conectar();
            
            String resultSecuencia = "select * from secuencia";
            PreparedStatement statement = conexion.prepareStatement(resultSecuencia);
            ResultSet resultado = statement.executeQuery();
         
                 while(resultado.next()){
                  
                     for(int i=0; i<secuencias.size();i++){ 
                     if(secuencias.get(i).getId().equals(resultado.getString(1))){
                         encontro= true;
                          System.out.println("encontrado"+secuencias.get(i).getId());
                          break;
                     }
                     else{                         
                         encontro=false;
                     }                     
                }
                 
         }
              conexion.close();  
        
        } catch (SQLException e) {
            System.err.println("Error de SQL al guardar la secuencia: " + e.getMessage());
            e.printStackTrace();
        }
        return encontro;  
    }
    
   public String verificarAnalisisAlineamiento(String secuencia1, String secuencia2) {
         String mensaje = "mostrar";
       try{
            Connection conexion = conectar.conectar();
            
            String consultaAlineamiento = "select * from alineamiento where primeraSecuencia=? and segundaSecuencia=?";
            
            
            PreparedStatement statement = conexion.prepareStatement(consultaAlineamiento);
            statement.setString(1, secuencia1);
                statement.setString(2, secuencia2);
           
            ResultSet resultado = statement.executeQuery();
            
            
            while(resultado.next()){
                mensaje="";
                String similitud = String.format("%.2f",Double.parseDouble(resultado.getString(7)));
                JOptionPane.showMessageDialog(null,"Conteo secuencia 1: "+resultado.getInt(4)+"\n"+
                                                    "Conteo secuencia 2: "+resultado.getInt(5)+"\n"+
                                                    "Secuencia más larga: "+resultado.getString(6)+"\n"+
                                                    "Similitud: "+similitud+"%");
                reporte.reporteAlineamiento(secuencia1, secuencia2, resultado.getInt(4),resultado.getInt(5),resultado.getString(6),similitud);
                
            }
         
            
            conexion.close();
       } catch (SQLException e) {
            System.err.println("Error de SQL al guardar la secuencia: " + e.getMessage());
            e.printStackTrace();
        }
       return mensaje;
     }  
   
   public void guardarAnalisisAli(String sec1,String sec2,int contSec1, int contSec2, String secLarga,double similitud){
       try  {
           Connection conexion = conectar.conectar();
        String simil = Double.toString(similitud);
        String sql = "INSERT INTO alineamiento (primeraSecuencia,segundaSecuencia,longitudPrimera,longitudSegunda,secuenciaMasLarga,similitud) VALUES (?, ?, ?, ?, ?, ?)";
        
       
            PreparedStatement statement = conexion.prepareStatement(sql);
           
                //statement.setInt(1, 1);
                statement.setString(1, sec1);
                statement.setString(2, sec2);
                statement.setInt(3, contSec1);
                statement.setInt(4, contSec2);
                statement.setString(5, secLarga);
                statement.setString(6, simil);
                
                int filasAfectadas = statement.executeUpdate();
            
                if (filasAfectadas > 0) {
                    System.out.println("Analisis de alineamiento guardada exitosamente en BD.");
                    reporte.reporteAlineamiento(sec1, sec2, contSec1, contSec2, secLarga,simil);
                } else {
                    System.out.println("Error al guardar el analisis.");
                }
                
            conexion.close();

        } catch (SQLException e) {
            System.err.println("Error de SQL al guardar la secuencia: " + e.getMessage());
            e.printStackTrace();
        }
   }
   
   public List<Integer> verificarAnalisisMotivos(String secuencia, String motivo){
       
        List<Integer> motivosE = new ArrayList<>();
       
       try{
          
            Connection conexion = conectar.conectar();
            
            String consultaMotivo = "select * from motivos where secuencia=? and motivo=?";
            
            
            PreparedStatement statement = conexion.prepareStatement(consultaMotivo);
            statement.setString(1, secuencia);
                statement.setString(2, motivo);
            ResultSet resultado = statement.executeQuery();
            
            
            while(resultado.next()){
                 
                    motivosE.add(resultado.getInt(4));
            }
            reporte.reporteMotivos(secuencia,motivo,motivosE.size());
            
            conexion.close();
       } catch (SQLException e) {
            System.err.println("Error de SQL al guardar la secuencia: " + e.getMessage());
            e.printStackTrace();
        }
       
       
       return motivosE;      
       
   }
   
   
   public void guardarAnalisisMotivos(String secuencia, String motivo, List<Integer> motivosEncontrados){
       
       try  {
           Connection conexion = conectar.conectar();
           int filasAfectadas=0;
       
        String sql = "INSERT INTO motivos (secuencia,motivo,motivosEncontrados) VALUES (?, ?, ?)";
        
       
            PreparedStatement statement = conexion.prepareStatement(sql);
           
             for(int i=0;i<motivosEncontrados.size();i++){
                   statement.setString(1, secuencia);
                statement.setString(2, motivo);
                statement.setInt(3, motivosEncontrados.get(i));
                
                
                filasAfectadas = statement.executeUpdate();
            
                
             }
              if (filasAfectadas > 0) {
                    System.out.println("Analisis de motivos guardada exitosamente en BD.");
                    reporte.reporteMotivos(secuencia,motivo,motivosEncontrados.size());
                } else {
                    System.out.println("Error al guardar el analisis.");
                }
                
            conexion.close();

        } catch (SQLException e) {
            System.err.println("Error de SQL al guardar la secuencia: " + e.getMessage());
            e.printStackTrace();
        }
   }
   
   public void guardarTipoEstructura(String secuencia, String tipoEstructura, double alfa, double beta){
       try  {
           Connection conexion = conectar.conectar();
           int filasAfectadas=0;
       
        String sql = "INSERT INTO tipoEstructura (secuencia,tipoEstructura,porcentajeAlfa,porcentajeBeta) VALUES (?, ?, ?, ?)";
        
       
            PreparedStatement statement = conexion.prepareStatement(sql);
           
             
                statement.setString(1, secuencia);
                statement.setString(2, tipoEstructura);
                statement.setDouble(3, alfa);
                statement.setDouble(4, beta);
                
                
                filasAfectadas = statement.executeUpdate();            
                
             
              if (filasAfectadas > 0) {
                    System.out.println("Analisis de tipo de estructura guardada exitosamente en BD.");
                    reporte.reporteConteos(secuencia,tipoEstructura,alfa,beta);
                } else {
                    System.out.println("Error al guardar el analisis.");
                }
                
            conexion.close();

        } catch (SQLException e) {
            System.err.println("Error de SQL al guardar la secuencia: " + e.getMessage());
            e.printStackTrace();
        }
   }
   
   public String verificarTipoEstructura(String secuencia){
       
       String mensaje="mostrar";
       
       try{
            Connection conexion = conectar.conectar();
            
            String consulta = "select * from tipoEstructura where secuencia=?";
            
            
            PreparedStatement statement = conexion.prepareStatement(consulta);
            statement.setString(1, secuencia);
           
            ResultSet resultado = statement.executeQuery();
            
            
            while(resultado.next()){
                
                JOptionPane.showMessageDialog(null,"tipo de estructura: "+resultado.getString(3)+"\n"+
                                                    "Porcentaje Alga: "+resultado.getDouble(4)+"\n"+
                                                    "Porcentaje Beta: "+resultado.getDouble(5));
                mensaje="";
                reporte.reporteConteos(secuencia,resultado.getString(3),resultado.getDouble(4),resultado.getDouble(5));
            }
         
            
            conexion.close();
       } catch (SQLException e) {
            System.err.println("Error de SQL al guardar la secuencia: " + e.getMessage());
            e.printStackTrace();
        }
       
       
       return mensaje;
   }
   
  

  
   
   
   
}
