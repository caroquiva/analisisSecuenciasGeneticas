/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arquitecturas.proxy;

import arquitecturas.modelo.SecuenciaGenetica;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author carol
 */
public class BDwriteProxy implements BDwrite{
private static GuardarSecuencia realWriter= new GuardarSecuencia();
    private final  boolean isUserAuthorized; 
    boolean verificacion;
    
   
    
    public BDwriteProxy(boolean authorized) {
        this.isUserAuthorized = authorized;
    }

    @Override
    public boolean guardarSecuencias(List<SecuenciaGenetica> secuencias) {
        
         String archivo = JOptionPane.showInputDialog("Nombre del archivo para generar reporte: ");
        realWriter.reporte.setNomArchivo(archivo);
        
        if (this.isUserAuthorized) {
            if (realWriter == null) {
              //  realWriter = new GuardarSecuencia();
            }
            System.out.println("PROXY: Autorización concedida. Verificando en DB.");
            verificacion= realWriter.verificarSecuencias(secuencias);
            if (!verificacion){
                System.out.println("Información guardada en BD");
                realWriter.guardarSecuencias(secuencias);
            }else{
                System.out.println("La secuencia ya esta en BD");
               verificacion = true; 
            }
        } else {
            System.err.println("PROXY: Acceso denegado. El usuario no está autorizado para escribir en la DB.");
        }
        return verificacion;
    }
    
    public String verificarAnalisisAlineamiento(String sec1,String sec2,int contSec1, int contSec2, String secLarga,double similutd){
       
           
            
            String analisisAli= realWriter.verificarAnalisisAlineamiento(sec1, sec2);
            
         if(analisisAli != ""){
                realWriter.guardarAnalisisAli(sec1, sec2, contSec1, contSec2, secLarga, similutd);
            }
         
          return analisisAli;
         
}
    
    public List<Integer> verificarAnalisisMotivos(String motivos, String secuencia){
      //  realWriter = new GuardarSecuencia();
        
        List<Integer> m = realWriter.verificarAnalisisMotivos(secuencia, motivos);
        
        return m;
    }
    
    public void guardarAnalisisMotivos(List<Integer> motivosEncontrados, String motivos, String secuencia){
       // realWriter = new GuardarSecuencia();
        realWriter.guardarAnalisisMotivos(secuencia,motivos,motivosEncontrados); 
    }
    
    
    public String verificarTipoE(String secuencia){
         String tipoE = realWriter.verificarTipoEstructura(secuencia);
         return tipoE;
    }
    
    public void guardarTipoEstructura(String secuencia, String tipoEstructura, double alfa, double beta){
  
            realWriter.guardarTipoEstructura(secuencia, tipoEstructura, alfa, beta);
       
    }
}
