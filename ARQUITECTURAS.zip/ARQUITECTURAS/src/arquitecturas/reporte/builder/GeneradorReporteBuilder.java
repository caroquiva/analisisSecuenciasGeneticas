/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arquitecturas.reporte.builder;

import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author carol
 */
public class GeneradorReporteBuilder implements ReporteBuilder{
    
    private String nomArchivo;   
    
    
    public GeneradorReporteBuilder(){}
    
    
    public String getNomArchivo() {
        return nomArchivo;
    }

    public void setNomArchivo(String nomArchivo) {
        this.nomArchivo = nomArchivo;
    }

    @Override
    public void reporteAlineamiento(String sec1, String sec2, int contSec1, int contSec2, String secLarga, String similitud) {
        String fileCsv = System.getProperty("user.home")+"\\Downloads\\"+this.nomArchivo+".csv";
        
        try (FileWriter writer = new FileWriter(fileCsv, true)) {
            writer.append("ALINEAMIENTO DE SECUENCIA");
            writer.append("\n");
            writer.append("Primera Secuencia");
            writer.append("\n");
            writer.append(sec1);
            writer.append("\n");
            writer.append("Segunda Secuencia");
            writer.append("\n");
            writer.append(sec2);
            writer.append("\n");
            writer.append("Conteo Secuencia 1 : "); writer.append(contSec1+"");
            writer.append("\n"); 
            writer.append("Conteo Secuencia 2: ");writer.append(contSec2+"");
            writer.append("\n");
            writer.append("Secuencia más larga");
            writer.append("\n");
            writer.append(secLarga); 
            writer.append("\n");
            writer.append("Similitud : "); writer.append(similitud); writer.append("%");
            writer.append("\n");         
           

            writer.flush(); 
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void reporteMotivos(String secuencia, String motivo, int motivosEncontrados) {
         String fileCsv = System.getProperty("user.home")+"\\Downloads\\"+this.nomArchivo+".csv";
        
        try (FileWriter writer = new FileWriter(fileCsv, true)) {
               
            writer.append("DETECCION DE MOTIVOS");
            writer.append("\n");
            writer.append("Secuencia");
            writer.append("\n");
            writer.append(secuencia);
            writer.append("\n");
            writer.append("Motivo: ");writer.append(motivo);
            writer.append("\n");
            writer.append("Cantidad de motivos encontrados : "); writer.append(motivosEncontrados+"");
            writer.append("\n");                   
           

            writer.flush(); 
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void reporteConteos(String secuencia, String tipoEstructura, double alfa, double beta) {
     String fileCsv = System.getProperty("user.home")+"\\Downloads\\"+this.nomArchivo+".csv";
        
        try (FileWriter writer = new FileWriter(fileCsv, true)) {
               
            writer.append("CONTEO DE SECUENCIA");
            writer.append("\n");
            writer.append("Secuencia");
            writer.append("\n");
            writer.append(secuencia);
            writer.append("\n");
            writer.append("Tipo de Estructura : ");writer.append(tipoEstructura);
            writer.append("\n");
            writer.append("Porcentaje Alfa : "); writer.append(alfa+"");
            writer.append("\n");  
            writer.append("Porcentaje Beta : "); writer.append(beta+"");
            writer.append("\n"); 
           

            writer.flush(); 
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}
