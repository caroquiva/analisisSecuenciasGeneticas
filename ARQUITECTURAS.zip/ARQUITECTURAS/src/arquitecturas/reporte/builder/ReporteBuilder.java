/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arquitecturas.reporte.builder;

/**
 *
 * @author carol
 */
public interface ReporteBuilder {
    
    void reporteAlineamiento(String sec1,String sec2,int contSec1, int contSec2, String secLarga,String similitud);
    void reporteMotivos(String secuencia, String motivo, int motivosEncontrados);
    void reporteConteos(String secuencia,String tipoEstructura,double alfa,double beta);
}
