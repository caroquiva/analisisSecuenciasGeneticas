/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arquitecturas.analisis;

import arquitecturas.modelo.SecuenciaGenetica;
import arquitecturas.proxy.BDwriteProxy;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author carol
 */
public class MotivosSecuencia implements AnalisisMotivos{
@Override
public List<Integer> analizar(SecuenciaGenetica secuencia1) {
    List<Integer> motivosEncontrados;
    String motivo = JOptionPane.showInputDialog("Motivo").toUpperCase();
    
    motivosEncontrados =  verificarMotivo(motivo,secuencia1.getId());
    
    if(motivosEncontrados.size() == 0){
        
        
         String texto = secuencia1.getSecuencia().toString();
    int motivoT = motivo.length();
    String regex = "((?<=\\G.{" + motivoT + "}))";
    
    String[] motivos = texto.split(regex);

    for (int i=0; i<motivos.length;i++) {
            System.out.println(motivos[i]);
            if(motivos[i].equals(motivo)){
            motivosEncontrados.add(i);
            }
            
        }
    guardarMotivo(motivosEncontrados,motivo,secuencia1.getId());
    }
 
          
    return motivosEncontrados;
}

public List<Integer> verificarMotivo(String motivo,String secuencia){
   
    BDwriteProxy writer = new BDwriteProxy(true);
    
     
     System.out.println(secuencia);
     List<Integer> guardado= writer.verificarAnalisisMotivos(motivo, secuencia);
     
     return guardado;
}

public void guardarMotivo(List<Integer> motivosE, String motivo,String secuencia){
    
    BDwriteProxy writer = new BDwriteProxy(true);
    
    writer.guardarAnalisisMotivos(motivosE,motivo,secuencia);
    
}
    
}
