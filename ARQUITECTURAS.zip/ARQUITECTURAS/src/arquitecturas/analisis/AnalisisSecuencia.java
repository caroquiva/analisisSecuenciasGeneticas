/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arquitecturas.analisis;

import arquitecturas.modelo.SecuenciaGenetica;

/**
 *
 * @author carol
 */
public interface AnalisisSecuencia {
    void analizar(SecuenciaGenetica secuencia1,SecuenciaGenetica secuencia2);
  
}
