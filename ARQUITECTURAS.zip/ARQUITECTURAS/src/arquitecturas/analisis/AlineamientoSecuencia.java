/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arquitecturas.analisis;

import arquitecturas.modelo.SecuenciaGenetica;
import arquitecturas.proxy.BDwriteProxy;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author carol
 */
public class AlineamientoSecuencia implements  AnalisisSecuencia{
@Override
public void analizar(SecuenciaGenetica secuencia1, SecuenciaGenetica secuencia2) {
        String seq1 = secuencia1.getSecuencia().toString();
        String seq2 = secuencia2.getSecuencia().toString();
    
        int contSeq1 = seq1.length();
        int contSeq2 = seq2.length();
        
        double similitud;
        String seqLarga;
        String result;


       if (contSeq1 > contSeq2){
        
        seqLarga = secuencia1.getId();
        similitud = ((double)contSeq2 / contSeq1)*100;
        result = String.format("%.2f",similitud);
        
       }
       else{
        seqLarga = secuencia2.getId();
        similitud = ((double)contSeq1 / contSeq2)*100;        
        result = String.format("%.2f",similitud);        
       }
       String mostrar=guardarBD(secuencia1.getId(),secuencia2.getId(),contSeq1,contSeq2,seqLarga,similitud);
       
       if(!mostrar.equals(""))
       {
           
        JOptionPane.showMessageDialog(null,"Conteo secuencia 1: "+contSeq1+"\n"+
                                                    "Conteo secuencia 2: "+contSeq2+"\n"+
                                                    "Secuencia más larga: "+seqLarga+"\n"+
                                                    "Similitud: "+result+"%");
        
       }
    
       
    }


public String guardarBD(String sec1,String sec2,int contSec1, int contSec2, String secLarga,double similutd) {
    
    BDwriteProxy writer = new BDwriteProxy(true);
    
    String mostrar=writer.verificarAnalisisAlineamiento(sec1, sec2, contSec1, contSec2, secLarga, similutd);
    return mostrar;
}

}

