/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arquitecturas.analisis;

/**
 *
 * @author carol
 */
public class AnalisisFactory {
    public static AnalisisSecuencia crearAnalisis(String tipo){
       
        switch (tipo) {
            case "1":
            System.out.println(tipo);
                return new AlineamientoSecuencia();
            case "2":
                                
            case "3":
            System.out.println(tipo);
                return new ConteoSecuencia();                
            
            default:
                throw new IllegalArgumentException("Tipo de análisis no soportado: " + tipo);
        }
        
    }

    public static AnalisisMotivos crearListaMotivos(){
        return new MotivosSecuencia();
    }
}
