/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arquitecturas.analisis;

import arquitecturas.modelo.SecuenciaGenetica;
import arquitecturas.proxy.BDwriteProxy;
import javax.swing.JOptionPane;

/**
 *
 * @author carol
 */
public class ConteoSecuencia implements AnalisisSecuencia{
    
    BDwriteProxy writer = new BDwriteProxy(true);
    
    
@Override
public void analizar(SecuenciaGenetica secuencia1,SecuenciaGenetica secuencia2) {
        String seq = secuencia1.getSecuencia().toString();
        
        String verificar = writer.verificarTipoE(secuencia1.getId());
        
        if(!verificar.equals("")){
            long countA = seq.chars().filter(c -> c == 'A').count();
        long countT = seq.chars().filter(c -> c == 'T').count();
        long countC = seq.chars().filter(c -> c == 'C').count();
        long countG = seq.chars().filter(c -> c == 'G').count();

        long suma = countA + countT + countC + countG;

        double porcentajeA = ((double)countA / suma)*100;
        double porcentajeT = ((double)countT / suma)*100;
        double porcentajeC = ((double)countC / suma)*100;
        double porcentajeG = ((double)countG / suma)*100;

        //Calcular estructuras
        System.out.println(porcentajeA);
        System.out.println(porcentajeT);
        System.out.println(porcentajeC);
        System.out.println(porcentajeG);
        System.out.println(suma);

        double tipoEstructuraAlfa = ((porcentajeA + porcentajeT)/ suma)*100;
        double tipoEstructuraBeta = ((porcentajeC + porcentajeG)/ suma)*100;
        String estructura;
        if(tipoEstructuraAlfa > 50.0){
            estructura = "Alfa con el : "+tipoEstructuraAlfa+" %";
        }
        else if(tipoEstructuraBeta > 50.0){
            estructura = "Beta con el : "+tipoEstructuraBeta+ " %";
        }
        else{
            estructura = "Mixta";
        }
       
        JOptionPane.showMessageDialog(null,"tipo de estructura: "+estructura+"\n"+
                                                    "Porcentaje Alfa: "+tipoEstructuraAlfa+"\n"+
                                                    "Porcentaje Beta: "+tipoEstructuraBeta);
        guardar(secuencia1.getId(),estructura,tipoEstructuraAlfa,tipoEstructuraBeta);
        }
       
     
    }
    

public void guardar(String secuencia, String tipo, double alfa, double beta){
    
          
     writer.guardarTipoEstructura(secuencia, tipo, alfa, beta);
}
}
